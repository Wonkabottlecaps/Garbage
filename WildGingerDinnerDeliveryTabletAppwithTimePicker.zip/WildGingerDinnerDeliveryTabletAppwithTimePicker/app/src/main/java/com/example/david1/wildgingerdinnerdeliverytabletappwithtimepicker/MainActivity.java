package com.example.david1.wildgingerdinnerdeliverytabletappwithtimepicker;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private TimePicker timePicker1;
    private Calendar calendar;
    private TextView deliverytime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        deliverytime=(TextView) findViewById(R.id.DeliveryText);
        Button btTime = (Button)findViewById(R.id.btnTime);
        timePicker1 = (TimePicker) findViewById(R.id.timePicker1);
        calendar = Calendar.getInstance();

        btTime.setOnClickListener(new OnClickListener(){


                    @Override
                    public void onClick(View v) {

                        new TimePickerDialog(MainActivity.this, listener,2,30,false);
                    }
                });
    }


    TimePickerDialog.OnTimeSetListener listener;

    }

